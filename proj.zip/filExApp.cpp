#include <iostream>
#include <string>
#include <bits/stdc++.h>

#define clear_terminal() printf("\033[H\033[2J")

#include "linux_cmd.h"
#include "terminal_utils.h"

using namespace std;

void hold_terminal(vector < pair<string, char > > file_list, int cursor_position_x, int cursor_position_y);

int main() {

	int cursor_position_x = 1, cursor_position_y = 1;

	keyboard_settings_off();

	clear_terminal();

	vector < pair<string, char > > file_list = ls_impl();	// defined in linux_cmd
	
	cursor_position(cursor_position_x, cursor_position_y);
	
	hold_terminal(file_list, cursor_position_x, cursor_position_y);

	fflush(stdin);

	keyboard_settings_on();
	return 0;	
}

void hold_terminal(vector < pair<string, char > > file_list, int cursor_position_x, int cursor_position_y) {
	while(1) {
		string input = keyboard_handle();
		if(input == "UP") {
			cursor_position(--cursor_position_x, cursor_position_y);
		} else if(input == "DOWN") {
			cursor_position(++cursor_position_x, cursor_position_y);
		} else if(input == "RIGHT") {
			cursor_position(cursor_position_x, ++cursor_position_y);
		} else if(input == "LEFT") {
			cursor_position(cursor_position_x, --cursor_position_y);
		}
		
		if(input == "ENTER") {

			/*int pid = fork();
			if (pid == 0) {
  				execl("/usr/bin/xdg-open", "xdg-open", file_list[cursor_position_x-1], (char *)0);
  				exit(1);
			}*/

			if(file_list[cursor_position_x-1].first == '.') {
				printf("\033[32;1H");
				cout << "hi";
				printf("\033[1;1H");
			}
			else if(file_list[cursor_position_x-1].second == '-') {
				system(("xdg-open " + file_list[cursor_position_x-1].first).c_str());	
			} else {
				clear_terminal();

				string path = file_list[cursor_position_x-1].first;
				printf("\033[32;1H");
				cout << endl << "path is : " << path << endl;
				printf("\033[1;1H");
				file_list = ls_impl(path);	// defined in linux_cmd

				cursor_position_x = 1;
				cursor_position_y = 1;

				cursor_position(cursor_position_x, cursor_position_y);
			}
			
		}

	}
}