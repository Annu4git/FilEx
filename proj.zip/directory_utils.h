#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <string>

#ifndef INC_DIRECTORY_UTILS_H
#define INC_DIRECTORY_UTILS_H

std::string get_current_directory_path();

#endif