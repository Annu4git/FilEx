#include <bits/stdc++.h>

#ifndef INC_FILE_UTILS_H
#define INC_FILE_UTILS_H

using namespace std;

vector < pair<string, char>> show_and_get_file_list(string s);

#endif
